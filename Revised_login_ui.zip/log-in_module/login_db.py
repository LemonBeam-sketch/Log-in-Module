from flask import Flask, request, render_template, redirect, url_for
import mysql.connector

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        role = request.form.get("role")
        first_name = request.form.get("first_name")
        last_name = request.form.get("last_name")
        middle_initial = request.form.get("middle_initial")
        email = request.form.get("email")

        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="AttendScan_DB"
        )
        cursor = conn.cursor()

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INT AUTO_INCREMENT PRIMARY KEY,
            first_name VARCHAR(255),
            last_name VARCHAR(255),
            middle_initial CHAR(1),
            email VARCHAR(255),
            student_num CHAR(7)
        )
        """)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS instructors (
            id INT AUTO_INCREMENT PRIMARY KEY,
            first_name VARCHAR(255),
            last_name VARCHAR(255),
            middle_initial CHAR(1),
            email VARCHAR(255),
            password VARCHAR(255)
        )
        """)

        if role == "student":
            student_num = request.form.get("student_num")
            cursor.execute(
                "INSERT INTO students (first_name, last_name, middle_initial, email, student_num) VALUES (%s, %s, %s, %s, %s)",
                (first_name, last_name, middle_initial, email, student_num)
            )
        elif role == "instructor":
            password = request.form.get("password")
            cursor.execute(
                "INSERT INTO instructors (first_name, last_name, middle_initial, email, password) VALUES (%s, %s, %s, %s, %s)",
                (first_name, last_name, middle_initial, email, password)
            )

        conn.commit()
        cursor.close()
        conn.close()

        return "Data successfully inserted!"

    return render_template('login_module.html')

if __name__ == '__main__':
    app.run(debug=True)